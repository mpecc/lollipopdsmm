To use the fernflower decompiler, just put the fernflower.jar file into the runtime/bin folder.
Only tested with fernflower 0.8.6, other version may fail.
