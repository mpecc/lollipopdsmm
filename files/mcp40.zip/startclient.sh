#!/bin/bash
python runtime/startclient.py conf/mcp.cfg
