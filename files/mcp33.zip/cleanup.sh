#!/bin/bash
python runtime/cleanup.py conf/mcp.cfg
