"""
the Internet Relay Chat (IRC) protocol
"""
