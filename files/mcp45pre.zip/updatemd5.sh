#!/bin/bash
python runtime/updatemd5.py "$@"
